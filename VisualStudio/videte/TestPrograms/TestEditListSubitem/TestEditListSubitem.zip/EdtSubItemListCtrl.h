#pragma once

/////////////////////////////////////////////////////////////////////////////
// CSubItemEdit window
class CSubItemEdit : public CEdit
{
	friend class CEdtSubItemListCtrl;

public:
	CSubItemEdit (CEdtSubItemListCtrl* pCtrl);
    virtual ~CSubItemEdit();

	BOOL StopEdit(BOOL bCancel, UINT endkey=0);

    //{{AFX_VIRTUAL(CSubItemEdit)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

protected:
    CEdtSubItemListCtrl*	m_pListCtrl;
	bool					m_isClosing;
    
    //{{AFX_MSG(CSubItemEdit)
    afx_msg void OnKillFocus(CWnd* pNewWnd);
    afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnNcDestroy();
	//}}AFX_MSG

    DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSetFocus(CWnd* pOldWnd);
};

/////////////////////////////////////////////////////////////////////////////
// CEdtSubItemListCtrl
class CEdtSubItemListCtrl : public CListCtrl
{
	friend class CSubItemEdit;
	DECLARE_DYNAMIC(CEdtSubItemListCtrl)

	struct sListItem
	{
		WORD wItem, wSubItem;
	};

public:
	CEdtSubItemListCtrl();
	virtual ~CEdtSubItemListCtrl();

	// Attributes
public:
	BOOL	GetSelection(int &nItem, int &nSubItem);
	int		GetSubItemCount();
	DWORD	GetSelectionID();
	BOOL	GetSubItemRect(int nItem, int nSubItem, CRect &rc);
	virtual BOOL CanEditSubItem(int nItem, int nSubItem);

	// Operations
public:
	BOOL SelectSubItem(int nItem, int nSubItem);
	BOOL SelectSubItemFromCursorPos(CPoint pt=CPoint(-1,-1));
	BOOL EditSubItem();
	BOOL OnArrow(UINT nKey, BOOL bEdit);
	BOOL ValidateAll();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung

protected:
	afx_msg void OnNMReturn(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdraw(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMClick(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMDblclk(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()


protected:
	union uListItem
	{
		sListItem	Cell;
		DWORD		dwID;
	} m_Selected;
	BOOL m_bEditEndOnLostFocus;
private:
	BOOL m_bIsEditing;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};


