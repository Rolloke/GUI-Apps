// EdtSubItemListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "TestEditListSubitem.h"
#include "EdtSubItemListCtrl.h"
#include ".\edtsubitemlistctrl.h"


/////////////////////////////////////////////////////////////////////////////
// CSubItemEdit
#define	NO_ITEM_ID			0xffffffff
#define ALREADY_SELECTED	2
#define WM_EDITINGLOSTFOCUS (WM_USER+1)

/////////////////////////////////////////////////////////////////////////////
CSubItemEdit::CSubItemEdit (CEdtSubItemListCtrl* pCtrl)
{
	m_pListCtrl = pCtrl;
	m_isClosing = false;
	m_pListCtrl->m_bIsEditing = TRUE;
}
/////////////////////////////////////////////////////////////////////////////
CSubItemEdit::~CSubItemEdit()
{
	m_pListCtrl->m_bIsEditing = FALSE;
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CSubItemEdit, CEdit)
    //{{AFX_MSG_MAP(CSubItemEdit)
    ON_WM_KILLFOCUS()
    ON_WM_CHAR()
    ON_WM_CREATE()
    ON_WM_GETDLGCODE()
	ON_WM_NCDESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSubItemEdit message handlers
BOOL CSubItemEdit::PreTranslateMessage (MSG* pMsg) 
{
    if (pMsg->message == WM_KEYDOWN)
    {
		switch (pMsg->wParam)
		{
			case VK_RETURN:
			case VK_DELETE:
			case VK_ESCAPE:
				::TranslateMessage (pMsg);
				::DispatchMessage (pMsg);
				return TRUE;		    	// DO NOT process further
			// case VK_TAB:
			case VK_LEFT:
				{
					int nStart, nEnd;
					GetSel(nStart, nEnd);
					if (   nStart == nEnd
						&& nStart == 0
						&& m_pListCtrl->OnArrow((UINT)pMsg->wParam, TRUE))
					{
						return TRUE;
					}
				}break;
			case VK_RIGHT:
				{
					int nLen = GetWindowTextLength();
					int nStart, nEnd;
					GetSel(nStart, nEnd);
					if (   nStart == nEnd
						&& nStart == nLen
						&& m_pListCtrl->OnArrow((UINT)pMsg->wParam, TRUE))
					{
						return TRUE;
					}
				}break;
			case VK_UP:
			case VK_DOWN:
				if (m_pListCtrl->OnArrow((UINT)pMsg->wParam, TRUE))
				{
					return TRUE;
				}break;
		}
    }

    return CEdit::PreTranslateMessage (pMsg);
}
/////////////////////////////////////////////////////////////////////////////
void CSubItemEdit::OnKillFocus (CWnd* pNewWnd) 
{
    CEdit::OnKillFocus(pNewWnd);

	//End edit?
	if(!m_isClosing)
	{
		if(m_pListCtrl->m_bEditEndOnLostFocus)
		{
			StopEdit(false);
		}
		else
		{
			//Notify list parent
			m_pListCtrl->GetParent()->SendMessage(WM_EDITINGLOSTFOCUS, (WPARAM) m_pListCtrl->GetSafeHwnd(), 0);
		}
	}
}
/////////////////////////////////////////////////////////////////////////////
void CSubItemEdit::OnChar (UINT nChar, UINT nRepCnt, UINT nFlags) 
{
//    BOOL Shift = GetKeyState (VK_SHIFT) < 0;
    switch (nChar)
    {
		case VK_ESCAPE :
		{	
			StopEdit(TRUE, VK_ESCAPE);
			return;
		}
		case VK_RETURN :
		{
			StopEdit(FALSE, VK_RETURN);
			return;
		}
    }

    CEdit::OnChar (nChar, nRepCnt, nFlags);
 
}
/////////////////////////////////////////////////////////////////////////////
int CSubItemEdit::OnCreate (LPCREATESTRUCT lpCreateStruct) 
{
    if (CEdit::OnCreate (lpCreateStruct) == -1)
		return -1;

    // Set the proper font
    CFont* Font = GetParent()->GetFont();
    SetFont (Font);

    SetFocus();
    SetSel (0, -1);
    return 0;
}
/////////////////////////////////////////////////////////////////////////////
UINT CSubItemEdit::OnGetDlgCode() 
{
    return CEdit::OnGetDlgCode();
//    return CEdit::OnGetDlgCode() | DLGC_WANTALLKEYS;
//    return CEdit::OnGetDlgCode() | DLGC_WANTARROWS ;
}
/////////////////////////////////////////////////////////////////////////////
//Stop editing
BOOL CSubItemEdit::StopEdit(BOOL bCancel, UINT endkey)
{
	m_isClosing = true;

	//Don't call SetListText to set the text. The reason is that
	//the object may be destoyed before DestroyWindow() in this function
	//is called.
	if (   !bCancel 
		&& !m_pListCtrl->UpdateData())
	{
		m_isClosing = false;
		return FALSE;
	}
	HWND hParent = ::GetParent(m_hWnd);
	DestroyWindow();
	switch (endkey)
	{
		case VK_RETURN: case VK_ESCAPE:
			::InvalidateRect(hParent, NULL, TRUE);
			break;
	}
	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
void CSubItemEdit::OnNcDestroy()
{
	CEdit::OnNcDestroy();

	delete this;
}

/////////////////////////////////////////////////////////////////////////////
// CEdtSubItemListCtrl
IMPLEMENT_DYNAMIC(CEdtSubItemListCtrl, CListCtrl)
CEdtSubItemListCtrl::CEdtSubItemListCtrl()
{
	m_Selected.dwID = NO_ITEM_ID;
	m_bEditEndOnLostFocus = TRUE;
	m_bIsEditing = FALSE;
}
/////////////////////////////////////////////////////////////////////////////
CEdtSubItemListCtrl::~CEdtSubItemListCtrl()
{
}

/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CEdtSubItemListCtrl, CListCtrl)
	ON_NOTIFY_REFLECT(NM_RETURN, OnNMReturn)
	ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnNMCustomdraw)
	ON_NOTIFY_REFLECT(NM_CLICK, OnNMClick)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnNMDblclk)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CEdtSubItemListCtrl message handlers
void CEdtSubItemListCtrl::DoDataExchange(CDataExchange* pDX)
{
	CString sText;
	DDX_Text(pDX, GetSelectionID(), sText);
	SetItemText(m_Selected.Cell.wItem, m_Selected.Cell.wSubItem, sText);
}
/////////////////////////////////////////////////////////////////////////////
void CEdtSubItemListCtrl::OnNMReturn(NMHDR *pNMHDR, LRESULT *pResult)
{
	EditSubItem();
	*pResult = 0;
}
/////////////////////////////////////////////////////////////////////////////
void CEdtSubItemListCtrl::OnNMCustomdraw(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLVCUSTOMDRAW pLVCD = reinterpret_cast<LPNMLVCUSTOMDRAW>(pNMHDR);
    if ( CDDS_PREPAINT == pLVCD->nmcd.dwDrawStage )
	{
        *pResult = CDRF_NOTIFYITEMDRAW;
	}
    else if ( CDDS_ITEMPREPAINT == pLVCD->nmcd.dwDrawStage )
	{
        // This is the pre-paint stage for an item.  We need to make another
        // request to be notified during the post-paint stage.
        *pResult = CDRF_NOTIFYSUBITEMDRAW;
	}
	
    else if ( (CDDS_ITEMPREPAINT| CDDS_SUBITEM) == pLVCD->nmcd.dwDrawStage )
	{
		CDC* pDC = CDC::FromHandle(pLVCD->nmcd.hdc);
		CRect rcSubItem;
		int nItem = (int)pLVCD->nmcd.dwItemSpec;
		int nBrushColor = COLOR_WINDOW;

		if (   m_Selected.Cell.wItem    == nItem 
			&& m_Selected.Cell.wSubItem == pLVCD->iSubItem)
		{
			nBrushColor = COLOR_3DLIGHT;
			if (GetDlgItem(GetSelectionID()))
			{
				return;
			}
		}
		
		CString sText = GetItemText(nItem, pLVCD->iSubItem);
		GetSubItemRect(nItem, pLVCD->iSubItem, rcSubItem);

		pDC->FillRect(rcSubItem, CBrush::FromHandle(GetSysColorBrush(nBrushColor)));
		pDC->SetBkMode(TRANSPARENT);
		rcSubItem.DeflateRect(1, 0);
		pDC->DrawText(sText, rcSubItem, DT_SINGLELINE|DT_LEFT);
		*pResult = CDRF_SKIPDEFAULT;	// We've painted everything.
	}
}
/////////////////////////////////////////////////////////////////////////////
void CEdtSubItemListCtrl::OnNMClick(NMHDR *pNMHDR, LRESULT *pResult)
{
	if (SelectSubItemFromCursorPos() == ALREADY_SELECTED)
	{
		EditSubItem();
	}
	*pResult = 0;
}
/////////////////////////////////////////////////////////////////////////////
void CEdtSubItemListCtrl::OnNMDblclk(NMHDR *pNMHDR, LRESULT *pResult)
{
	if (SelectSubItemFromCursorPos())
	{
		EditSubItem();
	}
	*pResult = 0;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CEdtSubItemListCtrl::OnArrow(UINT nKey, BOOL bEdit)
{
	CWnd *pWnd = GetDlgItem(GetSelectionID());
	int nNextItem = m_Selected.Cell.wItem, nNextSubItem = m_Selected.Cell.wSubItem;
	if (pWnd)
	{
		if (!((CSubItemEdit*)pWnd)->StopEdit(FALSE, nKey))
		{
			return TRUE;
		}
	}

	switch (nKey)
	{
		case VK_UP:    nNextItem--;    break;
		case VK_DOWN:  nNextItem++;    break;
		case VK_LEFT:  nNextSubItem--; break;
		case VK_RIGHT: nNextSubItem++; break;
		case VK_RETURN: break;
	}

	if (SelectSubItem(nNextItem, nNextSubItem) == TRUE || nKey == VK_RETURN)
	{
		if (bEdit)
		{
			EditSubItem();
		}
		else if (nKey == VK_RETURN)
		{
			InvalidateRect(NULL);
		}
	}
	else
	{
		switch (nKey)
		{
			case VK_UP:    nKey = VK_LEFT;  break;
			case VK_DOWN:  nKey = VK_RIGHT; break;
			case VK_LEFT:  
				m_Selected.Cell.wSubItem = GetSubItemCount()-1;
				if (m_Selected.Cell.wItem > 0)
				{
					nKey = VK_UP; 
				}
				else
				{
					nKey = VK_RETURN;
					m_Selected.Cell.wItem = GetItemCount()-1;
				}
				break;
			case VK_RIGHT: 
				m_Selected.Cell.wSubItem = 0;
				if (m_Selected.Cell.wItem < GetItemCount()-1)
				{
					nKey = VK_DOWN; 
				}
				else
				{
					nKey = VK_RETURN;
					m_Selected.Cell.wItem = 0;
				}
				break;
		}
		return OnArrow(nKey, bEdit);
	}
	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CEdtSubItemListCtrl::SelectSubItemFromCursorPos(CPoint pt)
{
	LVHITTESTINFO lvhi;
	if (pt == CPoint(-1,-1))
	{
		GetCursorPos(&lvhi.pt);
		ScreenToClient(&lvhi.pt);
	}
	else
	{
		lvhi.pt = pt;
	}
	SubItemHitTest(&lvhi);

	return SelectSubItem(lvhi.iItem, lvhi.iSubItem);
}
/////////////////////////////////////////////////////////////////////////////
BOOL CEdtSubItemListCtrl::SelectSubItem(int nItem, int nSubItem)
{
	if (m_bIsEditing)
	{
		return FALSE;
	}
	if (   m_Selected.Cell.wItem    != nItem
		|| m_Selected.Cell.wSubItem != nSubItem)
	{
		if (   IsBetween(nItem, 0, GetItemCount()-1)
			&& IsBetween(nSubItem, 0, GetSubItemCount()-1)
			)
		{
			m_Selected.Cell.wItem    = (WORD)nItem;
			m_Selected.Cell.wSubItem = (WORD)nSubItem;
			InvalidateRect(NULL);
			NMITEMACTIVATE nmia;
			ZERO_INIT(nmia);
			nmia.hdr.idFrom		= GetDlgCtrlID();
			nmia.hdr.hwndFrom	= m_hWnd;
			nmia.hdr.code		= LVN_ITEMACTIVATE;
			nmia.iItem			= nItem;
			nmia.iSubItem		= nSubItem;
			::SendMessage(GetParent()->GetSafeHwnd(),
				WM_NOTIFY, (WPARAM) nmia.hdr.idFrom, (LPARAM)&nmia);
			return TRUE;
		}
		return FALSE;
	}
	return ALREADY_SELECTED;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CEdtSubItemListCtrl::EditSubItem()
{
	if (   m_Selected.dwID != NO_ITEM_ID
		&& !m_bIsEditing
		&& CanEditSubItem(m_Selected.Cell.wItem, m_Selected.Cell.wSubItem)
		&& EnsureVisible(m_Selected.Cell.wItem, TRUE))
	{
		CRect rcSubItem;
		if (GetSubItemRect(m_Selected.Cell.wItem, m_Selected.Cell.wSubItem, rcSubItem))
		{
			CString sText = GetItemText(m_Selected.Cell.wItem, m_Selected.Cell.wSubItem);
			CSubItemEdit*pEdit = new CSubItemEdit(this);
			DWORD dwStyle = WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL|WS_BORDER;
			pEdit->Create(dwStyle, rcSubItem, this, GetSelectionID()); 
			pEdit->SetWindowText(sText);
			return TRUE;
		}
	}
	return FALSE;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CEdtSubItemListCtrl::CanEditSubItem(int nItem, int nSubItem)
{
	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
int CEdtSubItemListCtrl::GetSubItemCount()
{
	CHeaderCtrl* pHeaderCtrl = GetHeaderCtrl();
	if (pHeaderCtrl != NULL)
	{
		return pHeaderCtrl->GetItemCount();
	}
	return 1;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CEdtSubItemListCtrl::ValidateAll()
{
	CSubItemEdit*pEdit = new CSubItemEdit(this);
	CRect rcSubItem(0,0,0,0);
	DWORD dwStyle = WS_CHILD|ES_AUTOHSCROLL|WS_BORDER;
	pEdit->Create(dwStyle, rcSubItem, this, 0); 
	CString sText;
	for (m_Selected.Cell.wItem=0; m_Selected.Cell.wItem<GetItemCount(); m_Selected.Cell.wItem++)
	{
		for (m_Selected.Cell.wSubItem=0; m_Selected.Cell.wSubItem<GetSubItemCount(); m_Selected.Cell.wSubItem++)
		{
			pEdit->SetDlgCtrlID(GetSelectionID());
			sText = GetItemText(m_Selected.Cell.wItem, m_Selected.Cell.wSubItem);
			pEdit->SetWindowText(sText);
			pEdit->m_isClosing = true;
			if (!UpdateData())
			{
				pEdit->m_isClosing = false;
				GetSubItemRect(m_Selected.Cell.wItem, m_Selected.Cell.wSubItem, rcSubItem);
				pEdit->MoveWindow(rcSubItem);
				pEdit->ShowWindow(SW_SHOW);
				return FALSE;
			}
		}
	}
	pEdit->DestroyWindow();

	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CEdtSubItemListCtrl::GetSelection(int &nItem, int &nSubItem)
{
	if (m_Selected.dwID != NO_ITEM_ID)
	{
		nItem    = m_Selected.Cell.wItem;
		nSubItem = m_Selected.Cell.wSubItem;
		return TRUE;
	}
	return FALSE;
}
/////////////////////////////////////////////////////////////////////////////
DWORD CEdtSubItemListCtrl::GetSelectionID()
{
	return m_Selected.dwID + 1;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CEdtSubItemListCtrl::GetSubItemRect(int nItem, int nSubItem, CRect &rc)
{
	BOOL bReturn = CListCtrl::GetSubItemRect(nItem, nSubItem, LVIR_BOUNDS, rc);
	if (bReturn && nSubItem == 0 && GetSubItemCount() > 1)
	{
		CRect rc2;
		CListCtrl::GetSubItemRect(nItem, 1, LVIR_BOUNDS, rc2);
		rc.right = rc2.left;
	}
	return bReturn;
}
/////////////////////////////////////////////////////////////////////////////

BOOL CEdtSubItemListCtrl::PreTranslateMessage(MSG* pMsg)
{
    if (pMsg->message == WM_KEYDOWN)
    {
		switch (pMsg->wParam)
		{
			case VK_RETURN:
				EditSubItem();
				return TRUE;
			case VK_LEFT: case VK_RIGHT: case VK_UP: case VK_DOWN:
				OnArrow((UINT)pMsg->wParam, FALSE);
				return TRUE;
		}
	}
	return CListCtrl::PreTranslateMessage(pMsg);
}
