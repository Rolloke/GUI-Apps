// stdafx.cpp : Quelltextdatei, die nur die Standard-Includes einbindet
//  TestEditListSubitem.pch ist der vorcompilierte Header
//  stdafx.obj enth�lt die vorcompilierte Typinformation

#include "stdafx.h"


